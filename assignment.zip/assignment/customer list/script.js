document.addEventListener('DOMContentLoaded', async function () {
    const customerTableBody = document.getElementById('customer-table-body');

    const bearerToken = localStorage.getItem('bearerToken');

    if (!bearerToken) {
        console.error('Bearer token not found. Please authenticate first.');
        return;
    }

    try {

        const response = await fetch('https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${bearerToken}`
            }
        });

        if (response.ok) {
            const customerList = await response.json();
            customerList.forEach(customer => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${customer.customerId}</td>
                    <td>${customer.name}</td>
                    <td>${customer.email}</td>
                `;
                customerTableBody.appendChild(row);
            });
        } else {
            console.error('Error fetching customer list:', response.status, response.statusText);
        }
    } catch (error) {
        console.error('Error:', error);
    }
});
