document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('login-form');
    const message = document.getElementById('message');
    const authAPI = 'https://qa2.sunbasedata.com/sunbase/portal/api/assignment_auth.jsp';
    const customerAPI = 'https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp';
    
    loginForm.addEventListener('submit', async function (event) {
        event.preventDefault();
        const loginId = loginForm.loginId.value;
        const password = loginForm.password.value;

        try {
            const response = await fetch(authAPI, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    login_id: loginId,
                    password: password
                })
            });

            if (response.ok) {
                const data = await response.json();
                const bearerToken = data.token;
                localStorage.setItem('bearerToken', bearerToken);
                
                window.location.href = 'customer.html';
            } else {
                message.textContent = 'Login failed. Please check your credentials.';
            }
        } catch (error) {
            console.error('Error:', error);
            message.textContent = 'An error occurred.';
        }
    });
});
