document.addEventListener('DOMContentLoaded', function () {
    const customerForm = document.getElementById('customer-form');
    const deleteCustomerForm = document.getElementById('delete-customer-form');
    const customerList = document.getElementById('customer-list');
    const message = document.getElementById('message');
    const submitButton = document.getElementById('submit-button');
    const updateButton = document.getElementById('update-button');
    const customerAPI = 'https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp';
    const updateCustomerEndpoint = 'https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp';
    const createCustomerEndpoint = 'https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp';
    const deleteCustomerEndpoint = 'https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp';
    const authToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';

    function resetFormFields() {
    }
    customerForm.addEventListener('submit', async function (event) {
        event.preventDefault();
        const formData = new FormData(customerForm);

        try {
            const response = await fetch(customerForm.action, {
                method: customerForm.method,
                body: formData
            });
        } catch (error) {
            console.error('Error:', error);
            message.textContent = 'An error occurred.';
        }
    });

    updateButton.addEventListener('click', function () {
        submitButton.style.display = 'none';
        updateButton.style.display = 'inline-block';
        customerForm.action = updateCustomerEndpoint;
        customerForm.method = 'PUT';
        message.textContent = '';
    });

    deleteCustomerForm.addEventListener('submit', async function (event) {
        event.preventDefault();
        const customerId = deleteCustomerForm.customerId.value;

        try {
            const response = await fetch(deleteCustomerEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${authToken}`
                },
                body: JSON.stringify({
                    customerId: customerId
                })
            });
        } catch (error) {
            console.error('Error:', error);
            message.textContent = 'An error occurred.';
        }
    });
    fetchAndPopulateCustomerList();
});
